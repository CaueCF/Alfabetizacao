package com.example.alfabetizacao;

public class Elemento {

    private int imagem;
    private String textoImagem;

    public String getTextoImagem() {
        return textoImagem;
    }

    public void setTextoImagem(String textoImagem) {
        this.textoImagem = textoImagem;
    }

    public int getImagem() {
        return imagem;
    }

    public void setImagem(int imagem) {
        this.imagem = imagem;
    }


}
